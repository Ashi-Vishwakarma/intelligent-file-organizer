#!/usr/bin/env python3
"""
main.py
Entry point — launches CLI or GUI depending on the --gui flag.

Usage:
    python main.py --source ~/Downloads          # CLI
    python main.py --gui                         # Tkinter GUI
    python main.py --source ~/Downloads --dry-run
"""

import sys
import os

# Ensure src/ is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))


def main():
    if "--gui" in sys.argv:
        from gui import App
        app = App()
        app.mainloop()
    else:
        from cli import main as cli_main
        cli_main()


if __name__ == "__main__":
    main()
